#!/usr/bin/bash

# Remove all the pre_ and post_ files in the sub-families of the FG-dataset (group2 group2b group3S group3N group4 )

for family in C_N N N_N O P S Si;
do 
    cd $family;
    echo $family;
    rm -r pre_* post_*;
    ls;
    cd ..;
done
