# FG-dataset

This directory contains the FG-dataset divided by heteroatoms, including `C_N`, `N`, `N_N`, `O`, `P`, `S`, `Si`. More details can be found in the paper.
- `metal_surfaces` Just for the code to function properly, it doesn't make any real sense.


