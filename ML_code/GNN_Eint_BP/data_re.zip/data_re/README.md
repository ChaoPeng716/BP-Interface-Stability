# Data directory

Here all the data used in this work are stored. 

- `FG_dataset` : It stores the DFT training data grouped by Heteroatoms in different sub-folders (e.g., `S`). Each sub-folder contains at least these two files:  
    1. `structures`: Stores the VASP CONTCAR geometry files of that specific chemical family, named following the convention `xxxxx.contcar`, where `xxxxxxx` refers to the  simplified spelling of SMILES for small molecules (for input into Linux systems).
    2. `energies.dat`: A file containing the ground state energy in eV of each sample. Each line represents a sample. Example: `C1_CC-_CC_C1C_CCC-_O-O-S -0.372`.

- `Pred_dataset` includes  linear small molecules collected for high-throughput screening.